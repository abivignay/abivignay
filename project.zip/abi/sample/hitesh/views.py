from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def hi(Response):
	return HttpResponse("balaji")
def hello(Response):
	return HttpResponse("hello")
def dyn(response,name,age,gender,department):
    return HttpResponse("<font color='red'>name={}<br></font> <font color='blue'>age={}<br></font> <font color='green'>gender={}<br></font> <font color='pink'>department={}<br></font>".format(name,age,gender,department))
def db(response,name):
	return HttpResponse("<span style = 'color:red;'>abi hero")
def res(response,age):
     return HttpResponse("<h1><span style = 'color:red;'>23</h1>")
def  hi(response,gender):
	return HttpResponse("<center><h1><font color='blue'>male={}</center></font></h1>")
def welcome(request):
	return render(request,'a.html')
def image(request):
	return render(request,'image.html')
def js(request):
	return render(request,'js.html')
def css(request):
	return render(request,'css.html')


