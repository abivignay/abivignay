alert("welcome all")
confirm("Are you sure to talk")
prompt("hai")