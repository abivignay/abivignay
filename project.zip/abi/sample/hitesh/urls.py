from django.urls import path
from hitesh import views
urlpattern = [path('hello/',views.hello),]